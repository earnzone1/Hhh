package com.example.ui.viewmodel

import android.app.Application
import android.net.Uri
import android.widget.Toast
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.DubRepository
import com.example.data.PipelineStatus
import com.example.data.db.AppDatabase
import com.example.data.model.DubbingProject
import com.example.data.model.LanguageCatalog
import com.example.data.model.PlanTier
import com.example.data.model.SampleCatalog
import com.example.data.model.SampleVideoPreset
import com.example.data.model.SpeakerSegment
import com.example.data.model.SupportedLanguage
import com.example.data.model.UserAccount
import com.example.service.audio.DubAudioEngine
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import com.example.service.DubbingPipelineEngine
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withContext
import android.content.ContentValues
import android.os.Build
import android.provider.MediaStore
import android.os.Environment
import android.media.MediaScannerConnection
import java.io.File
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

@OptIn(ExperimentalCoroutinesApi::class)
class DubStudioViewModel(application: Application) : AndroidViewModel(application) {
    private val database = AppDatabase.getDatabase(application)
    val repository = DubRepository(database.dubDao())
    val audioEngine = DubAudioEngine(application)

    val currentUserEmail = repository.currentUserEmail
    val pipelineStatus = repository.currentPipelineStatus

    val currentUser: StateFlow<UserAccount?> = currentUserEmail.flatMapLatest { email ->
        if (email != null) {
            repository.getCurrentUser(email).catch { e ->
                Log.e("DubStudioViewModel", "Error in currentUser stream", e)
                emit(null)
            }
        } else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val savedProjects: StateFlow<List<DubbingProject>> = currentUserEmail.flatMapLatest { email ->
        if (email != null) {
            repository.getUserProjects(email).catch { e ->
                Log.e("DubStudioViewModel", "Error in savedProjects stream", e)
                emit(emptyList())
            }
        } else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Studio UI States
    private val _selectedPreset = MutableStateFlow<SampleVideoPreset?>(SampleCatalog.sampleVideos[0])
    val selectedPreset: StateFlow<SampleVideoPreset?> = _selectedPreset.asStateFlow()

    private val _customVideoUri = MutableStateFlow<Uri?>(null)
    val customVideoUri: StateFlow<Uri?> = _customVideoUri.asStateFlow()

    private val _customVideoTitle = MutableStateFlow<String>("")
    val customVideoTitle: StateFlow<String> = _customVideoTitle.asStateFlow()

    private val _selectedTargetLang = MutableStateFlow<SupportedLanguage>(LanguageCatalog.supportedLanguages[0]) // Default Bengali
    val selectedTargetLang: StateFlow<SupportedLanguage> = _selectedTargetLang.asStateFlow()

    private val _selectedSourceLang = MutableStateFlow<SupportedLanguage>(LanguageCatalog.supportedLanguages[1]) // Default English
    val selectedSourceLang: StateFlow<SupportedLanguage> = _selectedSourceLang.asStateFlow()

    private val _isCopyrightShieldEnabled = MutableStateFlow(true)
    val isCopyrightShieldEnabled: StateFlow<Boolean> = _isCopyrightShieldEnabled.asStateFlow()

    // Dialog Controls
    private val _showPricingDialog = MutableStateFlow(false)
    val showPricingDialog: StateFlow<Boolean> = _showPricingDialog.asStateFlow()

    private val _selectedPlanForPayment = MutableStateFlow<PlanTier?>(null)
    val selectedPlanForPayment: StateFlow<PlanTier?> = _selectedPlanForPayment.asStateFlow()

    private val _showAuthDialog = MutableStateFlow(false)
    val showAuthDialog: StateFlow<Boolean> = _showAuthDialog.asStateFlow()

    private val _showApkDownloadDialog = MutableStateFlow(false)
    val showApkDownloadDialog: StateFlow<Boolean> = _showApkDownloadDialog.asStateFlow()

    private val _previewDubbedMode = MutableStateFlow(true) // true: Dubbed, false: Original
    val previewDubbedMode: StateFlow<Boolean> = _previewDubbedMode.asStateFlow()

    private val _activePlaybackSegment = MutableStateFlow<SpeakerSegment?>(null)
    val activePlaybackSegment: StateFlow<SpeakerSegment?> = _activePlaybackSegment.asStateFlow()

    init {
        viewModelScope.launch {
            try {
                repository.initializeDefaultUserIfNone()
            } catch (e: Throwable) {
                Log.e("DubStudioViewModel", "Startup user initialization warning", e)
            }
        }
    }

    fun selectPresetVideo(preset: SampleVideoPreset) {
        _selectedPreset.value = preset
        _customVideoUri.value = null
        _customVideoTitle.value = preset.title
    }

    fun setCustomVideo(uri: Uri, fileName: String) {
        _customVideoUri.value = uri
        _selectedPreset.value = null
        _customVideoTitle.value = fileName.ifBlank { "Uploaded Video" }
    }

    fun setTargetLanguage(language: SupportedLanguage) {
        _selectedTargetLang.value = language
    }

    fun setSourceLanguage(language: SupportedLanguage) {
        _selectedSourceLang.value = language
    }

    fun toggleCopyrightShield(enabled: Boolean) {
        _isCopyrightShieldEnabled.value = enabled
    }

    fun setPreviewDubbedMode(isDubbed: Boolean) {
        _previewDubbedMode.value = isDubbed
    }

    fun startDubbingProcess() {
        val user = currentUser.value
        if (user == null) {
            _showAuthDialog.value = true
            return
        }

        val title = _customVideoTitle.value.ifBlank {
            _selectedPreset.value?.title ?: "AI Dubbing Video"
        }
        val uriStr = _customVideoUri.value?.toString() ?: _selectedPreset.value?.id ?: "sample_preset"
        val duration = _selectedPreset.value?.durationSec ?: 60

        viewModelScope.launch {
            repository.startAutomaticDubbingPipeline(
                userEmail = user.email,
                videoTitle = title,
                videoUri = uriStr,
                durationSec = duration,
                sourceLangCode = _selectedSourceLang.value.code,
                targetLangCode = _selectedTargetLang.value.code,
                targetLangName = _selectedTargetLang.value.name
            )
        }
    }

    fun resetPipeline() {
        audioEngine.stopAudio()
        repository.resetPipeline()
    }

    fun playSegmentAudio(segment: SpeakerSegment) {
        _activePlaybackSegment.value = segment
        val langCode = if (_previewDubbedMode.value) _selectedTargetLang.value.code else "en"
        audioEngine.playSegment(segment, langCode)
    }

    fun stopAudio() {
        audioEngine.stopAudio()
        _activePlaybackSegment.value = null
    }

    fun openPricingDialog() {
        _showPricingDialog.value = true
    }

    fun closePricingDialog() {
        _showPricingDialog.value = false
        _selectedPlanForPayment.value = null
    }

    fun selectPlanToBuy(plan: PlanTier) {
        if (plan == PlanTier.FREE) {
            Toast.makeText(getApplication(), "You are already using Free Trial tier.", Toast.LENGTH_SHORT).show()
            return
        }
        _selectedPlanForPayment.value = plan
    }

    fun submitPaymentTrx(
        plan: PlanTier,
        method: String,
        senderNumber: String,
        trxId: String,
        onSuccess: () -> Unit
    ) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            val result = repository.verifyAndSubmitPayment(
                email = user.email,
                plan = plan,
                method = method,
                senderNumber = senderNumber,
                transactionId = trxId
            )
            result.onSuccess { msg ->
                Toast.makeText(getApplication(), msg, Toast.LENGTH_LONG).show()
                closePricingDialog()
                onSuccess()
            }.onFailure { err ->
                Toast.makeText(getApplication(), err.message ?: "Verification failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun performLogin(email: String, pass: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val result = repository.loginOrCreateAccount(email, pass)
            result.onSuccess {
                Toast.makeText(getApplication(), "Welcome, ${it.email}!", Toast.LENGTH_SHORT).show()
                _showAuthDialog.value = false
                onSuccess()
            }.onFailure {
                Toast.makeText(getApplication(), it.message ?: "Login failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun openAuthDialog() {
        _showAuthDialog.value = true
    }

    fun closeAuthDialog() {
        _showAuthDialog.value = false
    }

    fun openApkDownloadDialog() {
        _showApkDownloadDialog.value = true
    }

    fun closeApkDownloadDialog() {
        _showApkDownloadDialog.value = false
    }

    fun logout() {
        repository.logout()
        _showAuthDialog.value = true
    }

    private val _pipelineStep = MutableStateFlow(0)
    val pipelineStep = _pipelineStep.asStateFlow()

    private val _pipelineTotal = MutableStateFlow(5)
    val pipelineTotal = _pipelineTotal.asStateFlow()

    private val _pipelineMessage = MutableStateFlow("")
    val pipelineMessage = _pipelineMessage.asStateFlow()

    private val _pipelineProgress = MutableStateFlow(0)
    val pipelineProgress = _pipelineProgress.asStateFlow()

    private val _outputVideoPath = MutableStateFlow("")
    val outputVideoPath = _outputVideoPath.asStateFlow()

    private val _isDubbingComplete = MutableStateFlow(false)
    val isDubbingComplete = _isDubbingComplete.asStateFlow()

    private val _errorMessage = MutableStateFlow("")
    val errorMessage = _errorMessage.asStateFlow()

    private var pipelineEngine: DubbingPipelineEngine? = null

    fun startDubbingPipeline(videoUri: Uri, context: android.content.Context) {
        _isDubbingComplete.value = false
        _errorMessage.value = ""
        pipelineEngine = DubbingPipelineEngine(context)
        pipelineEngine!!.startDubbing(
            videoUri = videoUri,
            sourceLanguage = _selectedSourceLang.value.name,
            targetLanguage = _selectedTargetLang.value.name,
            onProgress = { step, total, message ->
                _pipelineStep.value = step
                _pipelineTotal.value = total
                _pipelineMessage.value = message
                _pipelineProgress.value = (step * 100 / total)
            },
            onComplete = { outputPath ->
                _outputVideoPath.value = outputPath
                _isDubbingComplete.value = true
                _pipelineMessage.value = "Processing Complete!"
                _pipelineProgress.value = 100
            },
            onError = { error ->
                _errorMessage.value = error
            }
        )
    }

    override fun onCleared() {
        super.onCleared()
        audioEngine.shutdown()
        pipelineEngine?.cleanup()
    }
}
