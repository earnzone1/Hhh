package com.example.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Surface
import com.example.data.PipelineStatus
import com.example.ui.components.AiAnalysisCard
import com.example.ui.components.ApkDownloadDialog
import com.example.ui.components.AuthDialog
import com.example.ui.components.CopyrightShieldCard
import com.example.ui.components.LanguageSelectorSection
import com.example.ui.components.PipelineProgressView
import com.example.ui.components.PricingPaymentDialog
import com.example.ui.components.SavedDubsHistorySection
import com.example.ui.components.TopStudioBar
import com.example.ui.components.VideoPreviewResultSection
import com.example.ui.components.VideoUploadSection
import com.example.ui.theme.ImmersiveBg
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.ImmersiveGreenContainer
import com.example.ui.theme.ImmersiveGreenDark
import com.example.ui.theme.ImmersiveGreenPrimary
import com.example.ui.theme.ImmersiveSurface
import com.example.ui.theme.ImmersiveTextMuted
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary
import com.example.ui.viewmodel.DubStudioViewModel

@Composable
fun MainStudioScreen(
    viewModel: DubStudioViewModel,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val pipelineStatus by viewModel.pipelineStatus.collectAsState()
    val selectedPreset by viewModel.selectedPreset.collectAsState()
    val customUri by viewModel.customVideoUri.collectAsState()
    val customTitle by viewModel.customVideoTitle.collectAsState()
    val selectedTargetLang by viewModel.selectedTargetLang.collectAsState()
    val isCopyrightShieldEnabled by viewModel.isCopyrightShieldEnabled.collectAsState()

    val showPricingDialog by viewModel.showPricingDialog.collectAsState()
    val selectedPlanForPayment by viewModel.selectedPlanForPayment.collectAsState()
    val showAuthDialog by viewModel.showAuthDialog.collectAsState()
    val showApkDownloadDialog by viewModel.showApkDownloadDialog.collectAsState()

    val previewDubbedMode by viewModel.previewDubbedMode.collectAsState()
    val activePlaybackSegment by viewModel.activePlaybackSegment.collectAsState()
    val isPlayingAudio by viewModel.audioEngine.isPlaying.collectAsState()
    val savedProjects by viewModel.savedProjects.collectAsState()

    val videoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            val fileName = it.lastPathSegment ?: "video.mp4"
            viewModel.setCustomVideo(it, fileName)
        }
    }

    Scaffold(
        topBar = {
            TopStudioBar(
                user = currentUser,
                onTopUpClick = { viewModel.openPricingDialog() },
                onAuthClick = { viewModel.openAuthDialog() },
                onApkClick = { viewModel.openApkDownloadDialog() }
            )
        },
        containerColor = ImmersiveBg,
        modifier = modifier.fillMaxSize()
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // If Pipeline is in progress or completed, show the dedicated status / result views
            when (val currentStatus = pipelineStatus) {
                is PipelineStatus.Completed -> {
                    val segments = viewModel.repository.parseSegmentsFromJson(currentStatus.project.speakerSegmentsJson)
                    VideoPreviewResultSection(
                        project = currentStatus.project,
                        outputVideoPath = viewModel.outputVideoPath.collectAsState().value,
                        segments = segments,
                        isDubbedMode = previewDubbedMode,
                        onToggleDubbedMode = { viewModel.setPreviewDubbedMode(it) },
                        activeSegment = activePlaybackSegment,
                        isPlayingAudio = isPlayingAudio,
                        onPlaySegment = { viewModel.playSegmentAudio(it) },
                        onStopAudio = { viewModel.stopAudio() },
                        onDubAnother = { viewModel.resetPipeline() }
                    )
                }
                is PipelineStatus.Analyzing,
                is PipelineStatus.CopyrightChecking,
                is PipelineStatus.Translating,
                is PipelineStatus.VoiceGenerating,
                is PipelineStatus.AudioMixing,
                is PipelineStatus.VideoRendering,
                is PipelineStatus.Failed -> {
                    PipelineProgressView(
                        status = currentStatus,
                        onReset = { viewModel.resetPipeline() },
                        onOpenPricing = { viewModel.openPricingDialog() }
                    )
                }
                PipelineStatus.Idle -> {
                    // 1. VIDEO UPLOAD & PRESET PICKER
                    VideoUploadSection(
                        selectedPreset = selectedPreset,
                        customUri = customUri,
                        customTitle = customTitle,
                        onSelectPreset = { viewModel.selectPresetVideo(it) },
                        onCustomVideoPicked = { uri, name -> viewModel.setCustomVideo(uri, name) }
                    )

                    // 2. AUTOMATIC AI ANALYSIS (Auto-detected breakdown)
                    AiAnalysisCard(
                        preset = selectedPreset,
                        customTitle = customTitle
                    )

                    // 3. 100% COPYRIGHT-SAFE ENGINE (YouTube/Facebook Content-ID Protection)
                    CopyrightShieldCard(
                        isEnabled = isCopyrightShieldEnabled,
                        onToggle = { viewModel.toggleCopyrightShield(it) }
                    )

                    // 4. LANGUAGE TRANSLATION SELECTOR
                    LanguageSelectorSection(
                        selectedLanguage = selectedTargetLang,
                        onSelectLanguage = { viewModel.setTargetLanguage(it) }
                    )

                    // START DUBBING ACTION BUTTON
                    ElevatedButton(
                        onClick = { viewModel.startDubbingProcess() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("start_dubbing_button"),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.elevatedButtonColors(
                            containerColor = ImmersiveGreenPrimary,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            modifier = Modifier.size(22.dp),
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Start AI Dubbing (${selectedTargetLang.localName})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = Color.White
                        )
                    }

                    // QUOTA HINT FOOTER
                    val userRemaining = currentUser?.remainingMinutes ?: 0.0
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Quota remaining: ${String.format("%.1f", userRemaining)} Minutes • Deducted ONLY on success",
                            style = MaterialTheme.typography.labelSmall,
                            color = ImmersiveTextMuted,
                            fontSize = 11.sp
                        )
                    }

                    // 5. PRODUCTION RELEASE APK DOWNLOAD CARD
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = ImmersiveSurface,
                        border = BorderStroke(1.dp, ImmersiveBorder),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.openApkDownloadDialog() }
                            .testTag("apk_download_card")
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(ImmersiveGreenPrimary),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Android,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = "Release APK Build v1.0",
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = ImmersiveTextPrimary,
                                                fontSize = 14.sp
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = ImmersiveGreenContainer
                                            ) {
                                                Text(
                                                    text = "VERIFIED",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = ImmersiveGreenDark,
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 9.sp,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            text = "Build Date: September 2026 • 24.8 MB • Signed",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = ImmersiveTextMuted,
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                ElevatedButton(
                                    onClick = { viewModel.openApkDownloadDialog() },
                                    colors = ButtonDefaults.elevatedButtonColors(
                                        containerColor = ImmersiveGreenPrimary,
                                        contentColor = Color.White
                                    ),
                                    shape = RoundedCornerShape(12.dp),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Download,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "Download",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // RECENT DUBBED PROJECTS HISTORY
            SavedDubsHistorySection(projects = savedProjects)
        }
    }

    // PRICING & PAYMENT MODAL
    if (showPricingDialog) {
        PricingPaymentDialog(
            user = currentUser,
            selectedPlan = selectedPlanForPayment,
            onSelectPlan = { viewModel.selectPlanToBuy(it) },
            onSubmitPayment = { plan, method, number, trx ->
                viewModel.submitPaymentTrx(plan, method, number, trx) {}
            },
            onDismiss = { viewModel.closePricingDialog() }
        )
    }

    // AUTH (LOGIN / REGISTER) MODAL
    if (showAuthDialog) {
        AuthDialog(
            currentUser = currentUser,
            onLoginOrRegister = { email, pass ->
                viewModel.performLogin(email, pass) {}
            },
            onLogout = { viewModel.logout() },
            onDismiss = { viewModel.closeAuthDialog() }
        )
    }

    // APK DOWNLOAD & RELEASE AUDIT MODAL
    if (showApkDownloadDialog) {
        ApkDownloadDialog(
            onDismiss = { viewModel.closeApkDownloadDialog() }
        )
    }
}
