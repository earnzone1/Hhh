package com.example.service

import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.service.dubbing.VideoProcessingEngine
import com.example.service.dubbing.WhisperEngine
import kotlinx.coroutines.*
import java.io.File
import java.util.Locale

class DubbingPipelineEngine(private val context: Context) {

    private val translationEngine = TranslationEngine()
    private val whisperEngine = WhisperEngine()
    private var tts: TextToSpeech? = null

    fun startDubbing(
        videoUri: Uri,
        sourceLanguage: String,
        targetLanguage: String,
        onProgress: (step: Int, total: Int, message: String) -> Unit,
        onComplete: (outputVideoPath: String) -> Unit,
        onError: (String) -> Unit
    ) {
        val cacheDir = context.cacheDir.absolutePath
        val inputVideoPath = "$cacheDir/input_video.mp4"
        val extractedAudioPath = "$cacheDir/extracted_audio.m4a"
        val ttsOutputPath = "$cacheDir/dubbed_audio.wav"
        val finalOutputPath = "$cacheDir/dubbed_output.mp4"

        CoroutineScope(Dispatchers.IO).launch {

            // STEP 1
            onProgress(1, 5, "Copying video to workspace...")
            val videoEngine = VideoProcessingEngine(context)
            val copiedPath = videoEngine.copyVideoToCache(videoUri, context)
            if (copiedPath.isEmpty()) {
                onError("Failed to read video file.")
                return@launch
            }

            // STEP 2
            onProgress(2, 5, "Extracting audio from video...")
            val audioExtracted = videoEngine.extractAudioFromVideo(
                inputVideoPath, extractedAudioPath
            )
            if (!audioExtracted) {
                onError("Failed to extract audio.")
                return@launch
            }

            // STEP 3
            onProgress(3, 5, "Transcribing speech...")
            val transcript = whisperEngine.transcribe(
                extractedAudioPath, sourceLanguage
            )
            if (transcript.isBlank()) {
                onError("Could not transcribe audio. Is speech clear?")
                return@launch
            }

            // STEP 4
            onProgress(4, 5, "Translating to $targetLanguage...")
            var translatedText = ""
            var translationDone = false
            translationEngine.translate(
                text = transcript,
                sourceLanguage = sourceLanguage,
                targetLanguage = targetLanguage,
                onProgress = { msg ->
                    onProgress(4, 5, msg)
                },
                onSuccess = { result ->
                    translatedText = result
                    translationDone = true
                },
                onError = { error ->
                    onError(error)
                }
            )
            while (!translationDone) { delay(100) }

            // STEP 4.5
            onProgress(4, 5, "Generating $targetLanguage voice...")
            val ttsComplete = CompletableDeferred<Boolean>()
            withContext(Dispatchers.Main) {
                tts = TextToSpeech(context) { status ->
                    if (status == TextToSpeech.SUCCESS) {
                        val locale = when (targetLanguage.lowercase()) {
                            "bengali", "বাংলা" -> Locale("bn", "IN")
                            "hindi", "हिंदी" -> Locale("hi", "IN")
                            "arabic", "عربي" -> Locale("ar")
                            "spanish", "español" -> Locale("es", "ES")
                            "french", "français" -> Locale("fr", "FR")
                            "urdu", "اردو" -> Locale("ur", "PK")
                            else -> Locale.ENGLISH
                        }
                        tts?.language = locale
                        val params = Bundle()
                        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "tts_utterance_id")
                        tts?.synthesizeToFile(
                            translatedText,
                            params,
                            File(ttsOutputPath),
                            "tts_utterance_id"
                        )
                    } else {
                        ttsComplete.complete(false)
                    }
                }
                tts?.setOnUtteranceProgressListener(
                    object : UtteranceProgressListener() {
                        override fun onDone(utteranceId: String?) {
                            ttsComplete.complete(true)
                        }
                        override fun onError(utteranceId: String?) {
                            ttsComplete.complete(false)
                        }
                        override fun onStart(utteranceId: String?) {}
                    }
                )
            }
            val ttsSuccess = ttsComplete.await()
            if (!ttsSuccess) {
                onError("Voice generation failed.")
                return@launch
            }

            // STEP 5
            onProgress(5, 5, "Merging audio and video...")
            val merged = videoEngine.mergeAudioWithVideo(
                inputVideoPath, ttsOutputPath, finalOutputPath
            )
            if (!merged) {
                onError("Failed to merge audio with video.")
                return@launch
            }

            onComplete(finalOutputPath)
        }
    }

    fun cleanup() {
        translationEngine.cleanup()
        tts?.shutdown()
    }
}
