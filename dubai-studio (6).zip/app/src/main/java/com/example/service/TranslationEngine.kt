package com.example.service

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions

class TranslationEngine {

    private var translator: Translator? = null

    fun translate(
        text: String,
        sourceLanguage: String,
        targetLanguage: String,
        onProgress: (String) -> Unit,
        onSuccess: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        val sourceLang = getMLKitLanguageCode(sourceLanguage)
        val targetLang = getMLKitLanguageCode(targetLanguage)

        val options = TranslatorOptions.Builder()
            .setSourceLanguage(sourceLang)
            .setTargetLanguage(targetLang)
            .build()

        translator = Translation.getClient(options)

        val conditions = DownloadConditions.Builder()
            .requireWifi()
            .build()

        onProgress("Downloading language model if needed...")

        translator!!.downloadModelIfNeeded(conditions)
            .addOnSuccessListener {
                translator!!.translate(text)
                    .addOnSuccessListener { translatedText ->
                        onSuccess(translatedText)
                    }
                    .addOnFailureListener { error ->
                        onError("Translation failed: ${error.message}")
                    }
            }
            .addOnFailureListener { error ->
                onError("Model download failed: ${error.message}")
            }
    }

    private fun getMLKitLanguageCode(language: String): String {
        return when (language.lowercase()) {
            "bengali", "বাংলা" -> TranslateLanguage.BENGALI
            "hindi", "हिंदी" -> TranslateLanguage.HINDI
            "arabic", "عربي" -> TranslateLanguage.ARABIC
            "spanish", "español" -> TranslateLanguage.SPANISH
            "french", "français" -> TranslateLanguage.FRENCH
            "chinese", "中文" -> TranslateLanguage.CHINESE
            "japanese", "日本語" -> TranslateLanguage.JAPANESE
            "korean", "한국어" -> TranslateLanguage.KOREAN
            "urdu", "اردو" -> TranslateLanguage.URDU
            else -> TranslateLanguage.ENGLISH
        }
    }

    fun cleanup() {
        translator?.close()
    }
}
