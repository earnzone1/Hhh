package com.example.data.db

import android.content.Context
import android.util.Log
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.DubbingProject
import com.example.data.model.PaymentRecord
import com.example.data.model.UserAccount

@Database(
    entities = [
        UserAccount::class,
        PaymentRecord::class,
        DubbingProject::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dubDao(): DubDao

    companion object {
        private const val DB_NAME = "dubi_studio_database"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                try {
                    db.execSQL("ALTER TABLE users ADD COLUMN createdAt INTEGER NOT NULL DEFAULT 0")
                } catch (e: Throwable) {
                    Log.w("AppDatabase", "Column createdAt might already exist: ${e.message}")
                }
                try {
                    db.execSQL("ALTER TABLE dubbing_projects ADD COLUMN copyrightShieldActive INTEGER NOT NULL DEFAULT 1")
                } catch (e: Throwable) {
                    Log.w("AppDatabase", "Column copyrightShieldActive might already exist: ${e.message}")
                }
                try {
                    db.execSQL("ALTER TABLE dubbing_projects ADD COLUMN copyrightSafetyScore INTEGER NOT NULL DEFAULT 100")
                } catch (e: Throwable) {
                    Log.w("AppDatabase", "Column copyrightSafetyScore might already exist: ${e.message}")
                }
                try {
                    db.execSQL("ALTER TABLE dubbing_projects ADD COLUMN copyrightDetails TEXT NOT NULL DEFAULT ''")
                } catch (e: Throwable) {
                    Log.w("AppDatabase", "Column copyrightDetails might already exist: ${e.message}")
                }
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val current = INSTANCE
                if (current != null && current.isOpen) {
                    return current
                }
                val newInstance = try {
                    val db = buildDatabase(context)
                    // Trigger schema check to catch schema mismatch / corrupted DB immediately
                    db.openHelper.writableDatabase
                    db
                } catch (e: Throwable) {
                    Log.e("AppDatabase", "Failed to open or migrate database safely. Rebuilding cleanly.", e)
                    try {
                        context.applicationContext.deleteDatabase(DB_NAME)
                    } catch (delEx: Throwable) {
                        Log.e("AppDatabase", "Failed to delete corrupted database", delEx)
                    }
                    val freshDb = buildDatabase(context)
                    try {
                        freshDb.openHelper.writableDatabase
                    } catch (freshEx: Throwable) {
                        Log.e("AppDatabase", "Secondary DB open warning", freshEx)
                    }
                    freshDb
                }
                INSTANCE = newInstance
                newInstance
            }
        }

        private fun buildDatabase(context: Context): AppDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                DB_NAME
            )
            .addMigrations(MIGRATION_1_2)
            .fallbackToDestructiveMigration(dropAllTables = true)
            .fallbackToDestructiveMigrationOnDowngrade(dropAllTables = true)
            .build()
        }
    }
}

