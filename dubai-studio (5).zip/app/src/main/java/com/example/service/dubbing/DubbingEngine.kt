package com.example.service.dubbing

/**
 * Interface for the core dubbing pipeline.
 */
interface DubbingEngine {
    fun processVideo(videoPath: String, targetLanguage: String)
}
