package com.example.service.dubbing

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.util.Log


/**
 * Handles Audio/Video foundation tasks using local processing.
 * Phase 1 Implementation.
 */
class VideoProcessingEngine(private val context: Context) {
    private val TAG = "VideoProcessingEngine"

    fun processVideo(videoUri: Uri, whisperEngine: WhisperEngine) {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(context, videoUri, null)
            
            var audioTrackIndex = -1
            var audioFormat: MediaFormat? = null

            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIndex = i
                    audioFormat = format
                    break
                }
            }

            if (audioTrackIndex == -1) {
                Log.e(TAG, "No audio track found")
                return
            }

            extractor.selectTrack(audioTrackIndex)
            val codec = MediaCodec.createDecoderByType(audioFormat!!.getString(MediaFormat.KEY_MIME)!!)
            codec.configure(audioFormat, null, null, 0)
            codec.start()

            val bufferInfo = MediaCodec.BufferInfo()
            var isEOS = false

            while (!isEOS) {
                val inputBufferIndex = codec.dequeueInputBuffer(10000)
                if (inputBufferIndex >= 0) {
                    val inputBuffer = codec.getInputBuffer(inputBufferIndex)!!
                    val sampleSize = extractor.readSampleData(inputBuffer, 0)
                    if (sampleSize < 0) {
                        codec.queueInputBuffer(inputBufferIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        isEOS = true
                    } else {
                        codec.queueInputBuffer(inputBufferIndex, 0, sampleSize, extractor.sampleTime, 0)
                        extractor.advance()
                    }
                }

                var outputBufferIndex = codec.dequeueOutputBuffer(bufferInfo, 10000)
                while (outputBufferIndex >= 0) {
                    val outputBuffer = codec.getOutputBuffer(outputBufferIndex)!!
                    // Here we would get PCM data. 
                    // TODO: Implement actual Downmix/Resampling to 16kHz Mono PCM.
                    val pcmData = ByteArray(outputBuffer.remaining())
                    outputBuffer.get(pcmData)
                    whisperEngine.transcribePcm(pcmData.map { it.toFloat() / 128f }.toFloatArray())
                    
                    codec.releaseOutputBuffer(outputBufferIndex, false)
                    outputBufferIndex = codec.dequeueOutputBuffer(bufferInfo, 0)
                }
            }

            codec.stop()
            codec.release()
            extractor.release()

        } catch (e: Exception) {
            Log.e(TAG, "Error processing video", e)
        }
    }
}
