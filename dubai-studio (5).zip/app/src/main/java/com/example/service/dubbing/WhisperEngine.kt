package com.example.service.dubbing

class WhisperEngine {
    init {
        System.loadLibrary("whisper")
    }

    external fun loadWhisperModel(modelPath: String): Boolean
    external fun isWhisperModelLoaded(): Boolean
    external fun transcribePcm(pcmData: FloatArray): String
    external fun releaseWhisper()
}
