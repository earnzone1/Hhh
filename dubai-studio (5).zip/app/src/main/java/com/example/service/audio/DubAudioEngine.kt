package com.example.service.audio

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.example.data.model.SpeakerSegment
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class DubAudioEngine(private val context: Context) : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var isInitialized = false

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _currentSegmentIndex = MutableStateFlow(0)
    val currentSegmentIndex: StateFlow<Int> = _currentSegmentIndex.asStateFlow()

    private val _activeSpeakerName = MutableStateFlow("")
    val activeSpeakerName: StateFlow<String> = _activeSpeakerName.asStateFlow()

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Throwable) {
            Log.e("DubAudioEngine", "Failed to instantiate TextToSpeech engine", e)
            tts = null
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isPlaying.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isPlaying.value = false
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isPlaying.value = false
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    _isPlaying.value = false
                }
            })
        } else {
            Log.e("DubAudioEngine", "TTS Initialization failed: $status")
        }
    }

    fun playSegment(segment: SpeakerSegment, langCode: String) {
        if (!isInitialized || tts == null) return

        val locale = when (langCode) {
            "bn" -> Locale("bn", "BD")
            "hi" -> Locale("hi", "IN")
            "es" -> Locale("es", "ES")
            "fr" -> Locale.FRENCH
            "de" -> Locale.GERMAN
            "ja" -> Locale.JAPANESE
            "zh" -> Locale.CHINESE
            "ar" -> Locale("ar")
            else -> Locale.US
        }

        val result = tts?.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.language = Locale.US
        }

        // Adjust pitch and rate based on gender and emotion
        if (segment.gender.equals("Female", ignoreCase = true)) {
            tts?.setPitch(1.15f)
            tts?.setSpeechRate(1.02f)
        } else {
            tts?.setPitch(0.88f)
            tts?.setSpeechRate(0.98f)
        }

        _activeSpeakerName.value = segment.speakerName
        _currentSegmentIndex.value = segment.speakerIndex

        val textToSpeak = segment.translatedText.ifBlank { segment.originalText }
        tts?.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, null, "segment_${segment.speakerIndex}")
    }

    fun stopAudio() {
        tts?.stop()
        _isPlaying.value = false
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
