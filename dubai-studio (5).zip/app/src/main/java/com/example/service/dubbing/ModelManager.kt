package com.example.service.dubbing

import android.content.Context
import java.io.File
import java.io.FileOutputStream

/**
 * Manages local models for the dubbing engine.
 */
enum class ModelStatus {
    NOT_INSTALLED,
    LOADING,
    READY,
    ERROR
}

data class ModelInfo(
    val name: String,
    val status: ModelStatus,
    val progress: Int
)

class ModelManager(private val context: Context) {
    fun getModelStatus(modelName: String): ModelStatus {
        val modelFile = File(context.filesDir, "models/$modelName")
        return if (modelFile.exists() && modelFile.length() > 0) ModelStatus.READY else ModelStatus.NOT_INSTALLED
    }

    fun copyModelFromAssets(modelName: String): Boolean {
        val assetPath = "models/$modelName"
        val tempFile = File(context.filesDir, "models/${modelName}.tmp")
        val destFile = File(context.filesDir, "models/$modelName")
        
        return try {
            tempFile.parentFile?.mkdirs()
            context.assets.open(assetPath).use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            }
            tempFile.renameTo(destFile)
        } catch (e: Exception) {
            tempFile.delete()
            false
        }
    }
}
