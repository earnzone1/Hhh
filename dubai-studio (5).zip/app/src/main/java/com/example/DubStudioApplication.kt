package com.example

import android.app.Application
import android.util.Log
import com.example.data.db.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class DubStudioApplication : Application() {

    private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        setupUncaughtExceptionHandler()
        warmUpDatabaseSafely()
    }

    private fun setupUncaughtExceptionHandler() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Log.e("DubStudioApp", "Uncaught exception on thread ${thread.name}", throwable)
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }

    private fun warmUpDatabaseSafely() {
        applicationScope.launch {
            try {
                // Safely open/migrate database in background so that main thread encounters no disk contention
                val db = AppDatabase.getDatabase(this@DubStudioApplication)
                db.openHelper.writableDatabase
                Log.d("DubStudioApp", "DubAI Studio database initialized successfully.")
            } catch (e: Throwable) {
                Log.e("DubStudioApp", "Non-fatal warning during database pre-warming", e)
            }
        }
    }
}
