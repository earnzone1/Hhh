#include <jni.h>
#include <string>
#include <android/log.h>

#define LOG_TAG "WhisperJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_service_dubbing_WhisperEngine_loadWhisperModel(JNIEnv* env, jobject /* this */, jstring modelPath) {
    LOGI("loadWhisperModel called");
    // Actual model loading logic will go here
    return JNI_TRUE;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_example_service_dubbing_WhisperEngine_isWhisperModelLoaded(JNIEnv* env, jobject /* this */) {
    return JNI_TRUE;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_service_dubbing_WhisperEngine_transcribePcm(JNIEnv* env, jobject /* this */, jfloatArray pcmData) {
    return env->NewStringUTF("Transcribed text placeholder");
}

extern "C" JNIEXPORT void JNICALL
Java_com_example_service_dubbing_WhisperEngine_releaseWhisper(JNIEnv* env, jobject /* this */) {
    LOGI("releaseWhisper called");
}
