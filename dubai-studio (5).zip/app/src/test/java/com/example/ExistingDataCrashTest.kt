package com.example

import android.content.Context
import androidx.test.core.app.ActivityScenario
import androidx.test.core.app.ApplicationProvider
import com.example.data.DubRepository
import com.example.data.db.AppDatabase
import com.example.data.model.DubbingProject
import com.example.data.model.UserAccount
import com.example.service.gemini.GeminiDubbingEngine
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExistingDataCrashTest {

    @Test
    fun testFreshInstall() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        context.deleteDatabase("dubi_studio_database")

        val db = AppDatabase.getDatabase(context)
        val repo = DubRepository(db.dubDao(), GeminiDubbingEngine())
        repo.initializeDefaultUserIfNone()

        val defaultUser = db.dubDao().getUserByEmailOnce("user@dubaistudio.ai")
        assertNotNull("Default user should be created on fresh install", defaultUser)
        assertEquals("user@dubaistudio.ai", defaultUser?.email)
    }

    @Test
    fun testAppRestart() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val db = AppDatabase.getDatabase(context)
        val repo = DubRepository(db.dubDao(), GeminiDubbingEngine())
        repo.initializeDefaultUserIfNone()

        // Simulate app restart / reopen by fetching database instance again
        val reloadedDb = AppDatabase.getDatabase(context)
        val user = reloadedDb.dubDao().getUserByEmailOnce("user@dubaistudio.ai")
        assertNotNull("Data must persist across app restarts", user)
    }

    @Test
    fun testExistingDatabaseFromPreviousVersion() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        context.deleteDatabase("dubi_studio_database")
        val dbFile = context.getDatabasePath("dubi_studio_database")
        dbFile.parentFile?.mkdirs()

        // Simulate database created last night with version 1 and older/minimal schema
        val sqliteDb = android.database.sqlite.SQLiteDatabase.openOrCreateDatabase(dbFile, null)
        sqliteDb.version = 1
        sqliteDb.execSQL("CREATE TABLE IF NOT EXISTS users (email TEXT PRIMARY KEY NOT NULL, passwordHash TEXT NOT NULL, purchasedMinutes REAL NOT NULL, usedMinutes REAL NOT NULL, activePlanName TEXT NOT NULL)")
        sqliteDb.execSQL("INSERT INTO users (email, passwordHash, purchasedMinutes, usedMinutes, activePlanName) VALUES ('user@dubaistudio.ai', '123456', 15.0, 0.0, 'FREE TRIAL')")
        sqliteDb.close()

        // Now app starts and Room attempts to open dubi_studio_database with version 2
        val db = AppDatabase.getDatabase(context)
        val user = db.dubDao().getUserByEmailOnce("user@dubaistudio.ai")
        assertNotNull("User should survive migration or recovery", user)
        assertEquals("user@dubaistudio.ai", user?.email)
    }

    @Test
    fun testCorruptedDatabaseSelfHealing() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        context.deleteDatabase("dubi_studio_database")
        val dbFile = context.getDatabasePath("dubi_studio_database")
        dbFile.parentFile?.mkdirs()

        // Write completely corrupt byte junk into the database file
        FileOutputStream(dbFile).use { fos ->
            fos.write("CORRUPT_INVALID_SQLITE_HEADER_JUNK".toByteArray())
        }

        // App opens database - should safely catch error, clean up and re-initialize without crashing
        val db = AppDatabase.getDatabase(context)
        val dao = db.dubDao()
        val user = dao.getUserByEmailOnce("user@dubaistudio.ai")
        // App did not crash!
        assertTrue("Database recovered safely from corruption", true)
    }

    @Test
    fun testAndroid14MainActivityLaunch() {
        val scenario = ActivityScenario.launch(MainActivity::class.java)
        scenario.onActivity { activity ->
            assertNotNull("MainActivity must launch successfully on Android 14", activity)
        }
        scenario.close()
    }
}
