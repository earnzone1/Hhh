package com.example

import com.example.data.model.PaymentConfig
import com.example.data.model.PlanTier
import com.example.data.model.SampleCatalog
import com.example.data.model.UserAccount
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testPaymentConfigNumber() {
        assertEquals("01791310431", PaymentConfig.personalSendMoneyNumber)
        assertTrue(PaymentConfig.INSTRUCTION_BENGALI.contains("Send Money"))
    }

    @Test
    fun testPlanTiers() {
        assertEquals(0, PlanTier.FREE.priceBdt)
        assertEquals(5, PlanTier.FREE.totalMinutes)

        assertEquals(499, PlanTier.PREMIUM_120.priceBdt)
        assertEquals(120, PlanTier.PREMIUM_120.totalMinutes)

        assertEquals(1200, PlanTier.PREMIUM_300.priceBdt)
        assertEquals(300, PlanTier.PREMIUM_300.totalMinutes)

        assertEquals(2400, PlanTier.PREMIUM_600.priceBdt)
        assertEquals(600, PlanTier.PREMIUM_600.totalMinutes)

        assertEquals(3600, PlanTier.PREMIUM_900.priceBdt)
        assertEquals(900, PlanTier.PREMIUM_900.totalMinutes)

        assertEquals(5000, PlanTier.PREMIUM_1250.priceBdt)
        assertEquals(1250, PlanTier.PREMIUM_1250.totalMinutes)
    }

    @Test
    fun testUserAccountQuota() {
        val user = UserAccount(email = "test@studio.ai", passwordHash = "pass", purchasedMinutes = 5.0, usedMinutes = 2.0)
        assertEquals(3.0, user.remainingMinutes, 0.01)
    }

    @Test
    fun testSampleCatalogMultiSpeaker() {
        assertTrue(SampleCatalog.sampleVideos.isNotEmpty())
        val multiSpeakerDrama = SampleCatalog.sampleVideos.find { it.id == "sample_cinema_drama" }
        assertNotNull(multiSpeakerDrama)
        assertEquals(6, multiSpeakerDrama?.speakerCount)
        assertEquals(6, multiSpeakerDrama?.segments?.size)
        val firstSeg = multiSpeakerDrama?.segments?.get(0)
        assertNotNull(firstSeg)
        assertEquals("Urgent & Commanding", firstSeg?.emotion)
        assertTrue(firstSeg?.lipSyncTiming?.contains("Aligned") == true)
    }

    @Test
    fun testSpeakerSegmentAttributes() {
        val segment = com.example.data.model.SpeakerSegment(
            speakerIndex = 1,
            speakerName = "Speaker 01",
            gender = "Male",
            voiceTone = "Baritone",
            startTimeSec = 0f,
            endTimeSec = 10f,
            originalText = "Hello",
            translatedText = "হ্যালো",
            assignedVoiceName = "Natural Male Voice (Voice 01)",
            emotion = "Confident & Authoritative",
            pitchVariation = "Natural Intonation (±0.0 st)",
            speakingSpeed = "1.0x Syllable Synced",
            lipSyncTiming = "Neural Syllable-to-Mouth Aligned",
            overlapHandled = true,
            sceneContext = "Keynote Opening"
        )
        assertEquals(1, segment.speakerIndex)
        assertEquals("Confident & Authoritative", segment.emotion)
        assertTrue(segment.overlapHandled)
    }

    @Test
    fun testApkReleaseSpecifications() {
        val packageName = "com.aistudio.videodubbing.kqzvpt"
        val versionName = "1.0"
        val versionCode = 1
        assertEquals("com.aistudio.videodubbing.kqzvpt", packageName)
        assertEquals("1.0", versionName)
        assertEquals(1, versionCode)
    }
}
