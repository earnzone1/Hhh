package com.example.data.model

object SampleCatalog {
    val sampleVideos = listOf(
        SampleVideoPreset(
            id = "sample_tech_keynote",
            title = "AI & Future Technology Keynote",
            category = "Technology / Presentation",
            durationSec = 75,
            detectedOriginalLang = "en",
            detectedOriginalLangName = "English (US)",
            speakerCount = 2,
            speakerProfilesSummary = "2 Speakers: Speaker 1 (Male Lead Presenter) + Speaker 2 (Female AI Engineer)",
            segments = listOf(
                SpeakerSegment(
                    speakerIndex = 1,
                    speakerName = "Speaker 1 (David)",
                    gender = "Male",
                    voiceTone = "Professional Deep Resonance",
                    startTimeSec = 0f,
                    endTimeSec = 14f,
                    originalText = "Welcome everyone. Today we are revealing a revolutionary leap in autonomous artificial intelligence.",
                    translatedText = "সবাইকে স্বাগতম। আজ আমরা স্বায়ত্তশাসিত কৃত্রিম বুদ্ধিমত্তার ক্ষেত্রে এক বৈপ্লবিক অগ্রগতির উন্মোচন করছি।",
                    assignedVoiceName = "Natural Bengali Male (Voice 01)",
                    emotion = "Inspiring & Authoritative"
                ),
                SpeakerSegment(
                    speakerIndex = 2,
                    speakerName = "Speaker 2 (Sarah)",
                    gender = "Female",
                    voiceTone = "Clear Emotion-Aware Soprano",
                    startTimeSec = 15f,
                    endTimeSec = 32f,
                    originalText = "Our neural model understands natural human emotions, speech cadence, and real-time multilingual dubbing.",
                    translatedText = "আমাদের নিউরাল মডেল মানুষের স্বাভাবিক আবেগ, কথার গতি এবং রিয়েল-টাইম বহুভাষিক ডাবিং বুঝতে সক্ষম।",
                    assignedVoiceName = "Emotion-Aware Bengali Female (Voice 02)",
                    emotion = "Enthusiastic & Confident"
                ),
                SpeakerSegment(
                    speakerIndex = 1,
                    speakerName = "Speaker 1 (David)",
                    gender = "Male",
                    voiceTone = "Professional Deep Resonance",
                    startTimeSec = 33f,
                    endTimeSec = 52f,
                    originalText = "With smart audio ducking, background music is automatically balanced so the voice is crystal clear.",
                    translatedText = "স্মার্ট অডিও ডাকিং-এর মাধ্যমে ব্যাকগ্রাউন্ড মিউজিক স্বয়ংক্রিয়ভাবে ব্যালেন্স হয় যাতে ভয়েস একদম ক্রিস্টাল ক্লিয়ার শোনায়।",
                    assignedVoiceName = "Natural Bengali Male (Voice 01)",
                    emotion = "Engaging & Explanatory"
                ),
                SpeakerSegment(
                    speakerIndex = 2,
                    speakerName = "Speaker 2 (Sarah)",
                    gender = "Female",
                    voiceTone = "Clear Emotion-Aware Soprano",
                    startTimeSec = 53f,
                    endTimeSec = 75f,
                    originalText = "This allows creators around the world to reach global audiences effortlessly with zero language barriers.",
                    translatedText = "এর ফলে বিশ্বের যেকোনো ক্রিয়েটর কোনো ভাষার বাধা ছাড়াই সহজেই বিশ্বব্যাপী দর্শকদের কাছে পৌঁছাতে পারবেন।",
                    assignedVoiceName = "Emotion-Aware Bengali Female (Voice 02)",
                    emotion = "Warm & Visionary"
                )
            ),
            bgmType = "Cinematic Ambient Electronic (BGM Level: 20%)",
            soundFxType = "Subtle Stage Acoustics & Applause"
        ),
        SampleVideoPreset(
            id = "sample_cinema_drama",
            title = "Cinema Ensemble Drama (Multi-Character)",
            category = "Cinema / Multi-Character",
            durationSec = 120,
            detectedOriginalLang = "en",
            detectedOriginalLangName = "English (US)",
            speakerCount = 6,
            speakerProfilesSummary = "6 Characters: 3 Male + 3 Female (Distinct Timbre, Pitch & Accent Identities)",
            segments = listOf(
                SpeakerSegment(
                    speakerIndex = 1,
                    speakerName = "Speaker 01 (Captain Harrison)",
                    gender = "Male",
                    voiceTone = "Gravelly Authoritative Baritone",
                    startTimeSec = 0f,
                    endTimeSec = 18f,
                    originalText = "We have less than three hours before the storm hits the coast. Everyone check your stations.",
                    translatedText = "ঝড় উপকূলে আঘাত হানার আগে আমাদের হাতে তিন ঘণ্টারও কম সময় আছে। সবাই নিজ নিজ স্টেশনে অবস্থান নিন।",
                    assignedVoiceName = "Natural Bengali Male (Voice 01 - Baritone)",
                    emotion = "Urgent & Commanding"
                ),
                SpeakerSegment(
                    speakerIndex = 2,
                    speakerName = "Speaker 02 (Officer Elena)",
                    gender = "Female",
                    voiceTone = "Sharp High-Precision Alto",
                    startTimeSec = 19f,
                    endTimeSec = 38f,
                    originalText = "Sensors are already picking up massive atmospheric pressure drops. Navigation radar is locked.",
                    translatedText = "সেন্সরগুলো ইতোমধ্যেই বায়ুমণ্ডলীয় চাপের বিশাল পতন শনাক্ত করছে। নেভিগেশন রাডার লক করা হয়েছে।",
                    assignedVoiceName = "Natural Bengali Female (Voice 02 - Alto)",
                    emotion = "Alert & Focused"
                ),
                SpeakerSegment(
                    speakerIndex = 3,
                    speakerName = "Speaker 03 (Chief Engineer Marcus)",
                    gender = "Male",
                    voiceTone = "Warm Resonant Bass",
                    startTimeSec = 39f,
                    endTimeSec = 58f,
                    originalText = "Engines are running at ninety percent capacity. We can hold the defensive perimeter as long as needed.",
                    translatedText = "ইঞ্জিনগুলো নব্বই শতাংশ ক্ষমতায় চলছে। যতক্ষণ প্রয়োজন আমরা প্রতিরক্ষামূলক পরিধি ধরে রাখতে পারব।",
                    assignedVoiceName = "Natural Bengali Male (Voice 03 - Bass)",
                    emotion = "Confident & Steady"
                ),
                SpeakerSegment(
                    speakerIndex = 4,
                    speakerName = "Speaker 04 (Communications Lead Dr. Priya)",
                    gender = "Female",
                    voiceTone = "Melodic Soft Soprano",
                    startTimeSec = 59f,
                    endTimeSec = 78f,
                    originalText = "All satellite channels are synchronized. Ground control is awaiting our confirmation signal.",
                    translatedText = "সমস্ত স্যাটেলাইট চ্যানেল সিঙ্ক্রোনাইজ করা হয়েছে। গ্রাউন্ড কন্ট্রোল আমাদের নিশ্চিতকরণ সংকেতের জন্য অপেক্ষা করছে।",
                    assignedVoiceName = "Natural Bengali Female (Voice 04 - Soprano)",
                    emotion = "Calm & Reassuring"
                ),
                SpeakerSegment(
                    speakerIndex = 5,
                    speakerName = "Speaker 05 (Ensign Lucas)",
                    gender = "Male",
                    voiceTone = "Youthful Energetic Tenor",
                    startTimeSec = 79f,
                    endTimeSec = 98f,
                    originalText = "Sir, target coordinates acquired. All sub-systems report green across the grid.",
                    translatedText = "স্যার, টার্গেটের স্থানাঙ্ক পাওয়া গেছে। গ্রিড জুড়ে সমস্ত সাব-সিস্টেম সক্রিয় রয়েছে।",
                    assignedVoiceName = "Natural Bengali Male (Voice 05 - Tenor)",
                    emotion = "Eager & Respectful"
                ),
                SpeakerSegment(
                    speakerIndex = 6,
                    speakerName = "Speaker 06 (Mission Specialist Maya)",
                    gender = "Female",
                    voiceTone = "Warm Dynamic Mezzo-Soprano",
                    startTimeSec = 99f,
                    endTimeSec = 120f,
                    originalText = "Then let's make this mission count. We have one chance, and we won't let it slip.",
                    translatedText = "তাহলে এই মিশনটিকে সফল করে তোলা যাক। আমাদের হাতে একটাই সুযোগ আছে, এবং আমরা তা হাতছাড়া করব না।",
                    assignedVoiceName = "Natural Bengali Female (Voice 06 - Mezzo)",
                    emotion = "Determined & Inspiring"
                )
            ),
            bgmType = "Epic Cinematic Orchestral Strings & Brass (Level: 18%)",
            soundFxType = "Bridge Atmosphere, Radar Pings & Engine Hum"
        ),
        SampleVideoPreset(
            id = "sample_nature_doc",
            title = "Mysteries of Deep Ocean Life",
            category = "Documentary / Nature",
            durationSec = 60,
            detectedOriginalLang = "en",
            detectedOriginalLangName = "English (US)",
            speakerCount = 2,
            speakerProfilesSummary = "2 Speakers: Speaker 1 (Male Narrator) + Speaker 2 (Female Marine Biologist)",
            segments = listOf(
                SpeakerSegment(
                    speakerIndex = 1,
                    speakerName = "Speaker 01 (Narrator)",
                    gender = "Male",
                    voiceTone = "Cinematic Deep Storyteller",
                    startTimeSec = 0f,
                    endTimeSec = 18f,
                    originalText = "Deep beneath the ocean surface, where sunlight never penetrates, extraordinary creatures thrive in absolute darkness.",
                    translatedText = "মহাসাগরের অতল গভীরে, যেখানে সূর্যের আলো কখনো পৌঁছায় না, সেখানে চরম অন্ধকারে অসাধারণ সব প্রাণী বেঁচে থাকে।",
                    assignedVoiceName = "Cinematic Bengali Male (Voice 01)",
                    emotion = "Atmospheric & Mysterious"
                ),
                SpeakerSegment(
                    speakerIndex = 2,
                    speakerName = "Speaker 02 (Dr. Elena)",
                    gender = "Female",
                    voiceTone = "Scientific Expressive Female",
                    startTimeSec = 19f,
                    endTimeSec = 40f,
                    originalText = "Bioluminescence is their primary language here. They produce their own natural light to hunt and communicate.",
                    translatedText = "বায়োলুমিনেসেন্স হলো এখানে তাদের যোগাযোগের প্রধান ভাষা। শিকার করতে এবং যোগাযোগ করতে তারা নিজেরাই আলো তৈরি করে।",
                    assignedVoiceName = "Natural Bengali Female (Voice 02)",
                    emotion = "Fascinated & Informative"
                ),
                SpeakerSegment(
                    speakerIndex = 1,
                    speakerName = "Speaker 01 (Narrator)",
                    gender = "Male",
                    voiceTone = "Cinematic Deep Storyteller",
                    startTimeSec = 41f,
                    endTimeSec = 60f,
                    originalText = "Every dive into the Mariana trench reveals new species never seen before by humanity.",
                    translatedText = "মারিয়ানা ট্রাঞ্চের প্রতিটি অভিযান এমন সব নতুন প্রজাতির সন্ধান দেয় যা মানবজাতি এর আগে কখনো দেখেনি।",
                    assignedVoiceName = "Cinematic Bengali Male (Voice 01)",
                    emotion = "Awe-Inspiring"
                )
            ),
            bgmType = "Deep Atmospheric Orchestral Strings",
            soundFxType = "Underwater Hydrophone & Bubbles"
        ),
        SampleVideoPreset(
            id = "sample_business_interview",
            title = "Startup Founders Dialogue",
            category = "Business / Podcast",
            durationSec = 90,
            detectedOriginalLang = "en",
            detectedOriginalLangName = "English (US)",
            speakerCount = 2,
            speakerProfilesSummary = "2 Speakers: Speaker 1 (Female Podcast Host) + Speaker 2 (Male Tech Founder)",
            segments = listOf(
                SpeakerSegment(
                    speakerIndex = 1,
                    speakerName = "Speaker 01 (Maya - Host)",
                    gender = "Female",
                    voiceTone = "Energetic Friendly Host",
                    startTimeSec = 0f,
                    endTimeSec = 22f,
                    originalText = "What was the single biggest turning point that helped your software scale from zero to one million users?",
                    translatedText = "আপনার সফটওয়্যার শূন্য থেকে দশ লক্ষ ব্যবহারকারীতে উন্নীত করার পেছনে সবচেয়ে বড় মোড় ঘোরানো মুহূর্তটি কী ছিল?",
                    assignedVoiceName = "Dynamic Bengali Female (Voice 01)",
                    emotion = "Curious & Engaging"
                ),
                SpeakerSegment(
                    speakerIndex = 2,
                    speakerName = "Speaker 02 (Tariq - Founder)",
                    gender = "Male",
                    voiceTone = "Conversational Calm Male",
                    startTimeSec = 23f,
                    endTimeSec = 55f,
                    originalText = "We focused relentlessly on automation. Removing all manual friction for the user made the product irresistible.",
                    translatedText = "আমরা সম্পূর্ণ মনোযোগ দিয়েছিলাম অটোমেশনের উপর। ব্যবহারকারীর জন্য সমস্ত ম্যানুয়াল ঝামেলা দূর করাই প্রোডাক্টের সাফল্য এনে দেয়।",
                    assignedVoiceName = "Conversational Bengali Male (Voice 02)",
                    emotion = "Thoughtful & Confident"
                ),
                SpeakerSegment(
                    speakerIndex = 1,
                    speakerName = "Speaker 01 (Maya - Host)",
                    gender = "Female",
                    voiceTone = "Energetic Friendly Host",
                    startTimeSec = 56f,
                    endTimeSec = 90f,
                    originalText = "Simplicity always wins. When the AI takes care of all complex settings, everyone can produce studio quality output.",
                    translatedText = "সহজ সরল অভিজ্ঞতাই সবসময় বিজয়ী হয়। যখন এআই সমস্ত জটিল সেটিংস নিজে সামলায়, তখন সবাই স্টুডিও কোয়ালিটি আউটপুট পায়।",
                    assignedVoiceName = "Dynamic Bengali Female (Voice 01)",
                    emotion = "Enthusiastic Agreement"
                )
            ),
            bgmType = "Low-Fi Modern Studio Chill Beat",
            soundFxType = "Studio Room Tone"
        ),
        SampleVideoPreset(
            id = "sample_long_masterclass",
            title = "Long-Form Film Masterclass (60 Min)",
            category = "Education / Long-Form (60 Min)",
            durationSec = 3600, // 60 Minutes
            detectedOriginalLang = "en",
            detectedOriginalLangName = "English (US)",
            speakerCount = 4,
            speakerProfilesSummary = "4 Speakers: 2 Male Mentors + 2 Female Directing Fellows (Long Video 60 Min)",
            segments = listOf(
                SpeakerSegment(
                    speakerIndex = 1,
                    speakerName = "Speaker 01 (Professor Miller)",
                    gender = "Male",
                    voiceTone = "Academic Deep Resonance",
                    startTimeSec = 0f,
                    endTimeSec = 120f,
                    originalText = "In long-form cinematography, character voice consistency anchors the audience throughout multiple scenes.",
                    translatedText = "পূর্ণদৈর্ঘ্য সিনেমাটোগ্রাফিতে চরিত্রের কণ্ঠের ধারাবাহিকতা একাধিক দৃশ্য জুড়ে দর্শকদের গভীরভাবে যুক্ত রাখে।",
                    assignedVoiceName = "Natural Bengali Male (Voice 01)",
                    emotion = "Educated & Deep"
                ),
                SpeakerSegment(
                    speakerIndex = 2,
                    speakerName = "Speaker 02 (Director Sophie)",
                    gender = "Female",
                    voiceTone = "Artistic Expressive Alto",
                    startTimeSec = 121f,
                    endTimeSec = 240f,
                    originalText = "When translating high-stakes drama, keeping the original dialogue pacing and sound effects intact is crucial.",
                    translatedText = "উচ্চ-নাটকীয় দৃশ্য অনুবাদের সময় মূল সংলাপের গতি এবং শব্দপ্রভাব অক্ষুণ্ণ রাখা অত্যন্ত জরুরি।",
                    assignedVoiceName = "Natural Bengali Female (Voice 02)",
                    emotion = "Artistic & Passionate"
                )
            ),
            bgmType = "Subtle Acoustic Classical Piano (Ducked 20%)",
            soundFxType = "Auditorium Acoustics"
        )
    )
}
