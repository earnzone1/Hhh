package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.DubbingProject
import com.example.data.model.PaymentRecord
import com.example.data.model.UserAccount
import kotlinx.coroutines.flow.Flow

@Dao
interface DubDao {
    // User Management
    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    fun getUserByEmail(email: String): Flow<UserAccount?>

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    suspend fun getUserByEmailOnce(email: String): UserAccount?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserAccount)

    @Update
    suspend fun updateUser(user: UserAccount)

    @Query("UPDATE users SET usedMinutes = usedMinutes + :minutesUsed WHERE email = :email")
    suspend fun deductMinutes(email: String, minutesUsed: Double)

    @Query("UPDATE users SET purchasedMinutes = purchasedMinutes + :minutesAdded, activePlanName = :planName WHERE email = :email")
    suspend fun addPurchasedMinutes(email: String, minutesAdded: Double, planName: String)

    // Payments
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(record: PaymentRecord): Long

    @Query("SELECT * FROM payment_records WHERE userEmail = :email ORDER BY timestamp DESC")
    fun getPaymentsForUser(email: String): Flow<List<PaymentRecord>>

    // Dubbing Projects
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProject(project: DubbingProject): Long

    @Update
    suspend fun updateProject(project: DubbingProject)

    @Query("SELECT * FROM dubbing_projects WHERE userEmail = :email ORDER BY timestamp DESC")
    fun getProjectsForUser(email: String): Flow<List<DubbingProject>>

    @Query("SELECT * FROM dubbing_projects WHERE id = :id LIMIT 1")
    suspend fun getProjectById(id: Long): DubbingProject?

    @Query("DELETE FROM dubbing_projects WHERE id = :id")
    suspend fun deleteProjectById(id: Long)
}
