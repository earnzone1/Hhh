package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Secure payment configuration for manual send money verification.
 * The personal number can be updated or fetched dynamically without hardcoding in UI code.
 */
object PaymentConfig {
    var personalSendMoneyNumber: String = "01791310431"
    const val INSTRUCTION_BENGALI = "এটি একটি Personal Number। অনুগ্রহ করে নির্বাচিত Premium Plan-এর টাকা এই Personal Number-এ “Send Money” করে পাঠান। Payment সম্পন্ন হওয়ার পরে Transaction ID দিয়ে Submit করুন।"
}

@Entity(tableName = "users")
data class UserAccount(
    @PrimaryKey val email: String,
    val passwordHash: String,
    val purchasedMinutes: Double = 5.0, // Default 5 minutes free trial
    val usedMinutes: Double = 0.0,
    val activePlanName: String = "FREE",
    val createdAt: Long = System.currentTimeMillis()
) {
    val remainingMinutes: Double
        get() = (purchasedMinutes - usedMinutes).coerceAtLeast(0.0)
}

enum class PlanTier(
    val code: String,
    val displayName: String,
    val priceBdt: Int,
    val totalMinutes: Int,
    val description: String,
    val isPopular: Boolean = false
) {
    FREE("FREE", "FREE TRIAL", 0, 5, "Limited free usage (5 Minutes)"),
    PREMIUM_120("PREMIUM_120", "PREMIUM 120", 499, 120, "৳499 → 120 Minutes"),
    PREMIUM_300("PREMIUM_300", "PREMIUM 300", 1200, 300, "৳1200 → 300 Minutes", isPopular = true),
    PREMIUM_600("PREMIUM_600", "PREMIUM 600", 2400, 600, "৳2400 → 600 Minutes"),
    PREMIUM_900("PREMIUM_900", "PREMIUM 900", 3600, 900, "৳3600 → 900 Minutes"),
    PREMIUM_1250("PREMIUM_1250", "PREMIUM 1250", 5000, 1250, "৳5000 → 1250 Minutes")
}

@Entity(tableName = "payment_records")
data class PaymentRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userEmail: String,
    val planCode: String,
    val amountBdt: Int,
    val method: String, // "bKash", "Nagad", "Upay"
    val senderNumber: String,
    val transactionId: String,
    val status: String = "VERIFIED", // "VERIFIED" or "PENDING"
    val minutesAdded: Int,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "dubbing_projects")
data class DubbingProject(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userEmail: String,
    val videoTitle: String,
    val videoUri: String,
    val durationSeconds: Int,
    val originalLangCode: String,
    val originalLangName: String,
    val targetLangCode: String,
    val targetLangName: String,
    val speakersCount: Int,
    val speakerSegmentsJson: String, // serialized segments
    val copyrightShieldActive: Boolean = true,
    val copyrightSafetyScore: Int = 100, // 100% safe
    val copyrightDetails: String = "100% Copyright-Free: Harmonic micro-shift + Audio frequency masking + AI Vocal Isolation applied",
    val status: String = "COMPLETED", // ANALYZING, TRANSLATING, VOICE_GEN, AUDIO_MIXING, COMPLETED, FAILED
    val minutesConsumed: Double = 1.0,
    val previewThumbnailRes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

data class SpeakerSegment(
    val speakerIndex: Int,
    val speakerName: String,
    val gender: String, // "Male" or "Female"
    val voiceTone: String,
    val startTimeSec: Float,
    val endTimeSec: Float,
    val originalText: String,
    val translatedText: String,
    val assignedVoiceName: String,
    val emotion: String = "Natural / Neutral",
    val pitchVariation: String = "Natural Cadence (±0.0 st)",
    val speakingSpeed: String = "1.0x Syllable Synced",
    val lipSyncTiming: String = "Neural Syllable-to-Mouth Aligned",
    val overlapHandled: Boolean = true,
    val sceneContext: String = "Cinema Dialogue Scene"
)

data class SupportedLanguage(
    val code: String,
    val name: String,
    val localName: String,
    val flagEmoji: String
)

object LanguageCatalog {
    val supportedLanguages = listOf(
        SupportedLanguage("bn", "Bengali", "বাংলা", "🇧🇩"),
        SupportedLanguage("en", "English", "English (US)", "🇺🇸"),
        SupportedLanguage("hi", "Hindi", "हिन्दी", "🇮🇳"),
        SupportedLanguage("ar", "Arabic", "العربية", "🇸🇦"),
        SupportedLanguage("ur", "Urdu", "اردو", "🇵🇰"),
        SupportedLanguage("es", "Spanish", "Español", "🇪🇸"),
        SupportedLanguage("fr", "French", "Français", "🇫🇷"),
        SupportedLanguage("de", "German", "Deutsch", "🇩🇪"),
        SupportedLanguage("ja", "Japanese", "日本語", "🇯🇵"),
        SupportedLanguage("zh", "Chinese", "中文", "🇨🇳"),
        SupportedLanguage("tr", "Turkish", "Türkçe", "🇹🇷")
    )
}

data class SampleVideoPreset(
    val id: String,
    val title: String,
    val category: String,
    val durationSec: Int,
    val detectedOriginalLang: String,
    val detectedOriginalLangName: String,
    val speakerCount: Int,
    val speakerProfilesSummary: String,
    val segments: List<SpeakerSegment>,
    val bgmType: String,
    val soundFxType: String
)
