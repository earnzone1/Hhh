package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val ImmersiveColorScheme = lightColorScheme(
    primary = ImmersiveGreenPrimary,
    onPrimary = Color.White,
    primaryContainer = ImmersiveGreenContainer,
    onPrimaryContainer = ImmersiveGreenDark,
    secondary = ImmersiveGreenDark,
    onSecondary = Color.White,
    secondaryContainer = ImmersiveSurfaceVariant,
    onSecondaryContainer = ImmersiveTextPrimary,
    tertiary = StudioGold,
    background = ImmersiveBg,
    onBackground = ImmersiveTextBody,
    surface = ImmersiveSurface,
    onSurface = ImmersiveTextPrimary,
    surfaceVariant = ImmersiveSurfaceVariant,
    onSurfaceVariant = ImmersiveTextSecondary,
    outline = ImmersiveBorder,
    outlineVariant = ImmersiveBorderSubtle,
    error = StudioRed
)

@Composable
fun DubStudioTheme(
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = ImmersiveColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    DubStudioTheme(content = content)
}
