package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.PaymentConfig
import com.example.data.model.PlanTier
import com.example.data.model.UserAccount
import com.example.ui.theme.BKashColor
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.ImmersiveGreenContainer
import com.example.ui.theme.ImmersiveGreenDark
import com.example.ui.theme.ImmersiveGreenPrimary
import com.example.ui.theme.ImmersiveGreenText
import com.example.ui.theme.ImmersiveSurface
import com.example.ui.theme.ImmersiveSurfaceVariant
import com.example.ui.theme.ImmersiveTextMuted
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary
import com.example.ui.theme.NagadColor
import com.example.ui.theme.UpayColor

@Composable
fun PricingPaymentDialog(
    user: UserAccount?,
    selectedPlan: PlanTier?,
    onSelectPlan: (PlanTier) -> Unit,
    onSubmitPayment: (plan: PlanTier, method: String, senderNumber: String, trxId: String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var paymentMethod by remember { mutableStateOf("bKash") }
    var senderNumber by remember { mutableStateOf("") }
    var transactionId by remember { mutableStateOf("") }
    var isSubmitting by remember { mutableStateOf(false) }

    val personalNumber = PaymentConfig.personalSendMoneyNumber

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(vertical = 24.dp)
                .testTag("pricing_payment_dialog"),
            shape = RoundedCornerShape(28.dp),
            color = ImmersiveSurface,
            border = BorderStroke(1.dp, ImmersiveBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(22.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(ImmersiveGreenContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.Bolt, contentDescription = null, tint = ImmersiveGreenPrimary)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (selectedPlan != null) "Complete Payment" else "Video Dubbing Plans",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = ImmersiveTextPrimary
                            )
                            Text(
                                text = "Remaining Quota: ${String.format("%.1f", user?.remainingMinutes ?: 0.0)} Minutes",
                                style = MaterialTheme.typography.labelSmall,
                                color = ImmersiveGreenText
                            )
                        }
                    }

                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = ImmersiveTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                if (selectedPlan == null) {
                    // PLAN SELECTION VIEW
                    Text(
                        text = "CHOOSE A DUBBING & PROCESSING PLAN",
                        style = MaterialTheme.typography.labelSmall,
                        color = ImmersiveTextMuted,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        PlanTier.values().forEach { plan ->
                            PlanCardItem(
                                plan = plan,
                                isCurrentPlan = user?.activePlanName == plan.displayName,
                                onClick = { onSelectPlan(plan) }
                            )
                        }
                    }
                } else {
                    // PAYMENT FORM VIEW FOR SELECTED PLAN
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = ImmersiveGreenContainer,
                        border = BorderStroke(1.dp, ImmersiveGreenPrimary.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = selectedPlan.displayName,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = ImmersiveGreenDark
                                )
                                Text(
                                    text = "${selectedPlan.totalMinutes} Dubbing & Processing Minutes",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = ImmersiveGreenText
                                )
                            }

                            Text(
                                text = if (selectedPlan.priceBdt == 0) "FREE" else "৳${selectedPlan.priceBdt}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = ImmersiveGreenDark
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Text(
                        text = "1. SELECT PAYMENT METHOD",
                        style = MaterialTheme.typography.labelSmall,
                        color = ImmersiveTextMuted,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Payment Method Tabs (bKash, Nagad, Upay)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // bKash Button
                        val bkSelected = paymentMethod == "bKash"
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (bkSelected) BKashColor.copy(alpha = 0.15f) else ImmersiveSurfaceVariant,
                            border = BorderStroke(if (bkSelected) 1.5.dp else 1.dp, if (bkSelected) BKashColor else ImmersiveBorder),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { paymentMethod = "bKash" }
                                .testTag("select_bkash_method")
                        ) {
                            Row(
                                modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(BKashColor)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "bKash",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (bkSelected) BKashColor else ImmersiveTextPrimary,
                                    fontSize = 13.sp
                                )
                            }
                        }

                        // Nagad Button
                        val nagadSelected = paymentMethod == "Nagad"
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (nagadSelected) NagadColor.copy(alpha = 0.15f) else ImmersiveSurfaceVariant,
                            border = BorderStroke(if (nagadSelected) 1.5.dp else 1.dp, if (nagadSelected) NagadColor else ImmersiveBorder),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { paymentMethod = "Nagad" }
                                .testTag("select_nagad_method")
                        ) {
                            Row(
                                modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(NagadColor)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Nagad",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (nagadSelected) NagadColor else ImmersiveTextPrimary,
                                    fontSize = 13.sp
                                )
                            }
                        }

                        // Upay Button
                        val upaySelected = paymentMethod == "Upay"
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (upaySelected) UpayColor.copy(alpha = 0.15f) else ImmersiveSurfaceVariant,
                            border = BorderStroke(if (upaySelected) 1.5.dp else 1.dp, if (upaySelected) UpayColor else ImmersiveBorder),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { paymentMethod = "Upay" }
                                .testTag("select_upay_method")
                        ) {
                            Row(
                                modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(UpayColor)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Upay",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (upaySelected) UpayColor else ImmersiveTextPrimary,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Explicit Personal Number & Bengali Instruction Box
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = ImmersiveSurfaceVariant,
                        border = BorderStroke(1.dp, ImmersiveBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "Payment Number ($paymentMethod Personal):",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = ImmersiveTextSecondary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        text = personalNumber,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = when (paymentMethod) {
                                            "bKash" -> BKashColor
                                            "Nagad" -> NagadColor
                                            else -> UpayColor
                                        },
                                        fontSize = 18.sp
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("Payment Number", personalNumber))
                                        Toast.makeText(context, "Payment Number copied: $personalNumber", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "Copy",
                                        tint = ImmersiveGreenPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = PaymentConfig.INSTRUCTION_BENGALI,
                                style = MaterialTheme.typography.bodySmall,
                                color = ImmersiveTextSecondary,
                                fontSize = 12.sp,
                                lineHeight = 17.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Input Sender Phone Number
                    OutlinedTextField(
                        value = senderNumber,
                        onValueChange = { senderNumber = it },
                        label = { Text("Sender Mobile Number") },
                        placeholder = { Text("017XXXXXXXX") },
                        leadingIcon = { Icon(imageVector = Icons.Default.PhoneAndroid, contentDescription = null, tint = ImmersiveTextSecondary) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("sender_number_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ImmersiveGreenPrimary,
                            unfocusedBorderColor = ImmersiveBorder,
                            focusedTextColor = ImmersiveTextPrimary,
                            unfocusedTextColor = ImmersiveTextPrimary
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Input Transaction ID (TrxID)
                    OutlinedTextField(
                        value = transactionId,
                        onValueChange = { transactionId = it },
                        label = { Text("Transaction ID (TrxID)") },
                        placeholder = { Text("e.g. BK9281741K") },
                        leadingIcon = { Icon(imageVector = Icons.Default.ReceiptLong, contentDescription = null, tint = ImmersiveTextSecondary) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("trx_id_input"),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = ImmersiveGreenPrimary,
                            unfocusedBorderColor = ImmersiveBorder,
                            focusedTextColor = ImmersiveTextPrimary,
                            unfocusedTextColor = ImmersiveTextPrimary
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    // Submit Verification Button
                    ElevatedButton(
                        onClick = {
                            if (senderNumber.isBlank() || transactionId.isBlank()) {
                                Toast.makeText(context, "Please enter sender number & TrxID", Toast.LENGTH_SHORT).show()
                                return@ElevatedButton
                            }
                            isSubmitting = true
                            onSubmitPayment(selectedPlan, paymentMethod, senderNumber, transactionId)
                        },
                        colors = ButtonDefaults.elevatedButtonColors(
                            containerColor = ImmersiveGreenPrimary,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("submit_payment_button"),
                        enabled = !isSubmitting
                    ) {
                        if (isSubmitting) {
                            CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Verifying Transaction...", fontWeight = FontWeight.Bold, color = Color.White)
                        } else {
                            Icon(imageVector = Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(18.dp), tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Verify & Activate ${selectedPlan.totalMinutes} Minutes", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PlanCardItem(
    plan: PlanTier,
    isCurrentPlan: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = if (plan.isPopular) ImmersiveGreenContainer else ImmersiveSurfaceVariant,
        border = BorderStroke(
            if (plan.isPopular) 1.5.dp else 1.dp,
            if (plan.isPopular) ImmersiveGreenPrimary else ImmersiveBorder
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("plan_card_${plan.code}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = plan.displayName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (plan.isPopular) ImmersiveGreenDark else ImmersiveTextPrimary
                    )
                    if (plan.isPopular) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = ImmersiveGreenPrimary
                        ) {
                            Text(
                                text = "POPULAR",
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${plan.totalMinutes} Minutes AI Video Dubbing",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (plan.isPopular) ImmersiveGreenText else ImmersiveTextSecondary,
                    fontSize = 12.sp
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = if (plan.priceBdt == 0) "Free" else "৳${plan.priceBdt}",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (plan.isPopular) ImmersiveGreenDark else ImmersiveGreenPrimary
                )
                Text(
                    text = if (isCurrentPlan) "Active Tier" else "Select →",
                    style = MaterialTheme.typography.labelSmall,
                    color = ImmersiveGreenPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}
