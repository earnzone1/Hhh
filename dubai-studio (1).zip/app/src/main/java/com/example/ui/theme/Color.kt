package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Immersive UI - Clean Modern Emerald & Eco Slate Palette
val ImmersiveBg = Color(0xFFF8FAF6)
val ImmersiveSurface = Color(0xFFFFFFFF)
val ImmersiveSurfaceVariant = Color(0xFFF1F1EB)
val ImmersiveBorder = Color(0xFFE1E3DC)
val ImmersiveBorderSubtle = Color(0xFFECEEE7)

val ImmersiveGreenPrimary = Color(0xFF006D3A)
val ImmersiveGreenDark = Color(0xFF00522C)
val ImmersiveGreenContainer = Color(0xFFD7E8CD)
val ImmersiveGreenText = Color(0xFF006D3A)

val ImmersiveTextPrimary = Color(0xFF00210E)
val ImmersiveTextBody = Color(0xFF1A1C19)
val ImmersiveTextSecondary = Color(0xFF424940)
val ImmersiveTextMuted = Color(0xFF72796F)

// Video & Media Playback Canvas Dark Surfaces
val ImmersiveMediaDark = Color(0xFF1A1C19)
val ImmersiveMediaDarkElevated = Color(0xFF282A26)

// Accent & Functional colors
val StudioGold = Color(0xFFB45309)
val StudioRed = Color(0xFFB91C1C)
val StudioCyan = Color(0xFF0284C7)
val StudioPurple = Color(0xFF7C3AED)
val StudioIndigo = Color(0xFF4F46E5)
val StudioGreen = ImmersiveGreenPrimary

// Payment brand colors
val BKashColor = Color(0xFFD12053)
val NagadColor = Color(0xFFF7941D)
val UpayColor = Color(0xFF005BAC)

// Compatibility tokens
val StudioNavyDark = ImmersiveBg
val StudioNavyCard = ImmersiveSurface
val StudioNavySurface = ImmersiveSurfaceVariant
val StudioBorder = ImmersiveBorder
val StudioCyanGlow = ImmersiveGreenContainer
val TextPrimary = ImmersiveTextPrimary
val TextSecondary = ImmersiveTextSecondary
val TextMuted = ImmersiveTextMuted
