package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PipelineStatus
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.ImmersiveGreenContainer
import com.example.ui.theme.ImmersiveGreenDark
import com.example.ui.theme.ImmersiveGreenPrimary
import com.example.ui.theme.ImmersiveGreenText
import com.example.ui.theme.ImmersiveSurface
import com.example.ui.theme.ImmersiveSurfaceVariant
import com.example.ui.theme.ImmersiveTextMuted
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary
import com.example.ui.theme.StudioRed

@Composable
fun PipelineProgressView(
    status: PipelineStatus,
    onReset: () -> Unit,
    onOpenPricing: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    if (status is PipelineStatus.Idle) return

    val progressValue: Float
    val statusMsg: String
    val currentStepNumber: Int

    when (status) {
        is PipelineStatus.Analyzing -> {
            progressValue = status.progress
            statusMsg = status.message
            currentStepNumber = 1
        }
        is PipelineStatus.CopyrightChecking -> {
            progressValue = status.progress
            statusMsg = status.message
            currentStepNumber = 2
        }
        is PipelineStatus.Translating -> {
            progressValue = status.progress
            statusMsg = status.message
            currentStepNumber = 3
        }
        is PipelineStatus.VoiceGenerating -> {
            progressValue = status.progress
            statusMsg = status.message
            currentStepNumber = 4
        }
        is PipelineStatus.AudioMixing -> {
            progressValue = status.progress
            statusMsg = status.message
            currentStepNumber = 5
        }
        is PipelineStatus.VideoRendering -> {
            progressValue = status.progress
            statusMsg = status.message
            currentStepNumber = 6
        }
        is PipelineStatus.Completed -> {
            progressValue = 1.0f
            statusMsg = "Dubbing & Processing Complete!"
            currentStepNumber = 7
        }
        is PipelineStatus.Failed -> {
            progressValue = 0f
            statusMsg = status.errorMessage
            currentStepNumber = -1
        }
        PipelineStatus.Idle -> {
            progressValue = 0f
            statusMsg = ""
            currentStepNumber = 0
        }
    }

    val isError = status is PipelineStatus.Failed
    val isQuotaError = isError && (statusMsg.contains("মিনিট") || statusMsg.contains("Remaining") || statusMsg.contains("quota", ignoreCase = true))

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("pipeline_progress_card"),
        colors = CardDefaults.cardColors(containerColor = ImmersiveSurface),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(
            1.5.dp,
            if (isError) StudioRed else ImmersiveGreenPrimary
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isError) {
                        Icon(imageVector = Icons.Default.Error, contentDescription = null, tint = StudioRed)
                    } else if (status is PipelineStatus.Completed) {
                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = ImmersiveGreenPrimary)
                    } else {
                        CircularProgressIndicator(
                            modifier = Modifier.size(24.dp),
                            color = ImmersiveGreenPrimary,
                            strokeWidth = 2.5.dp
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = if (isError) "Processing Alert" else "Automatic AI Processing",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isError) StudioRed else ImmersiveTextPrimary
                    )
                }

                if (!isError && status !is PipelineStatus.Completed) {
                    Text(
                        text = "${(progressValue * 100).toInt()}%",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = ImmersiveGreenPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Progress Bar
            if (!isError) {
                LinearProgressIndicator(
                    progress = { progressValue },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp)),
                    color = ImmersiveGreenPrimary,
                    trackColor = ImmersiveSurfaceVariant,
                    strokeCap = StrokeCap.Round
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Status message
            Text(
                text = statusMsg,
                style = MaterialTheme.typography.bodyMedium,
                color = if (isError) StudioRed else ImmersiveTextSecondary,
                fontSize = 13.sp,
                lineHeight = 19.sp
            )

            if (!isError && status !is PipelineStatus.Completed) {
                Spacer(modifier = Modifier.height(16.dp))

                // Pipeline Step Mini List
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    StepItem(
                        stepNumber = 1,
                        label = "AI Video Analysis (Speaker, Gender, Emotion)",
                        isDone = currentStepNumber > 1,
                        isActive = currentStepNumber == 1
                    )
                    StepItem(
                        stepNumber = 2,
                        label = "100% Copyright-Safe Shield & Anti-Content-ID",
                        isDone = currentStepNumber > 2,
                        isActive = currentStepNumber == 2
                    )
                    StepItem(
                        stepNumber = 3,
                        label = "Context-Aware Dialogue Translation",
                        isDone = currentStepNumber > 3,
                        isActive = currentStepNumber == 3
                    )
                    StepItem(
                        stepNumber = 4,
                        label = "Neural Human Voice Generation (Female/Male)",
                        isDone = currentStepNumber > 4,
                        isActive = currentStepNumber == 4
                    )
                    StepItem(
                        stepNumber = 5,
                        label = "Smart Audio Mixing (Vocal + BGM Ducking 20%)",
                        isDone = currentStepNumber > 5,
                        isActive = currentStepNumber == 5
                    )
                    StepItem(
                        stepNumber = 6,
                        label = "Final Video Rendering & Alignment",
                        isDone = currentStepNumber > 6,
                        isActive = currentStepNumber == 6
                    )
                }
            }

            if (isError) {
                Spacer(modifier = Modifier.height(16.dp))
                if (isQuotaError) {
                    ElevatedButton(
                        onClick = {
                            onReset()
                            onOpenPricing()
                        },
                        colors = ButtonDefaults.elevatedButtonColors(
                            containerColor = ImmersiveGreenPrimary,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("add_premium_minutes_button")
                    ) {
                        Text("Add Premium Minutes (মিনিট যোগ করুন)", fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                }
                ElevatedButton(
                    onClick = onReset,
                    colors = ButtonDefaults.elevatedButtonColors(
                        containerColor = if (isQuotaError) ImmersiveSurfaceVariant else ImmersiveGreenPrimary,
                        contentColor = if (isQuotaError) ImmersiveTextPrimary else Color.White
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Dismiss & Return", fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun StepItem(
    stepNumber: Int,
    label: String,
    isDone: Boolean,
    isActive: Boolean
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            modifier = Modifier
                .size(22.dp)
                .clip(CircleShape)
                .background(
                    when {
                        isDone -> ImmersiveGreenPrimary
                        isActive -> ImmersiveGreenContainer
                        else -> ImmersiveSurfaceVariant
                    }
                ),
            contentAlignment = Alignment.Center
        ) {
            if (isDone) {
                Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(13.dp)
                )
            } else {
                Text(
                    text = "$stepNumber",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (isActive) ImmersiveGreenPrimary else ImmersiveTextMuted,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.width(10.dp))

        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
            color = when {
                isDone -> ImmersiveGreenDark
                isActive -> ImmersiveGreenPrimary
                else -> ImmersiveTextMuted
            },
            fontSize = 12.sp
        )
    }
}
