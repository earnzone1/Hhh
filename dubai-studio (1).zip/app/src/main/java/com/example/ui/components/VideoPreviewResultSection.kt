package com.example.ui.components

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.DubbingProject
import com.example.data.model.SpeakerSegment
import com.example.ui.theme.ImmersiveBg
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.ImmersiveGreenContainer
import com.example.ui.theme.ImmersiveGreenDark
import com.example.ui.theme.ImmersiveGreenPrimary
import com.example.ui.theme.ImmersiveGreenText
import com.example.ui.theme.ImmersiveMediaDark
import com.example.ui.theme.ImmersiveSurface
import com.example.ui.theme.ImmersiveSurfaceVariant
import com.example.ui.theme.ImmersiveTextBody
import com.example.ui.theme.ImmersiveTextMuted
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary

@Composable
fun VideoPreviewResultSection(
    project: DubbingProject,
    segments: List<SpeakerSegment>,
    isDubbedMode: Boolean,
    onToggleDubbedMode: (Boolean) -> Unit,
    activeSegment: SpeakerSegment?,
    isPlayingAudio: Boolean,
    onPlaySegment: (SpeakerSegment) -> Unit,
    onStopAudio: () -> Unit,
    onDubAnother: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isDownloading by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("video_preview_result_section"),
        colors = CardDefaults.cardColors(containerColor = ImmersiveSurface),
        shape = RoundedCornerShape(32.dp),
        border = BorderStroke(1.dp, ImmersiveBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Video Player Mockup Container (Immersive UI Style)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f)
                    .clip(RoundedCornerShape(20.dp))
                    .background(ImmersiveMediaDark)
                    .border(BorderStroke(1.dp, ImmersiveBorder), RoundedCornerShape(20.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.hero_dubbing_banner),
                    contentDescription = "Video Dubbed Preview",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.matchParentSize()
                )

                // Dark gradient overlay
                Box(
                    modifier = Modifier
                        .matchParentSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(
                                    Color.Black.copy(alpha = 0.45f),
                                    Color.Transparent,
                                    Color.Black.copy(alpha = 0.85f)
                                )
                            )
                        )
                )

                // 100% COPYRIGHT SAFE Badge on Top-Right
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = ImmersiveGreenPrimary,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.VerifiedUser,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(11.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "100% COPYRIGHT SAFE",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 9.sp
                        )
                    }
                }

                // Audio mode tag on Top-Left
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color.Black.copy(alpha = 0.7f),
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(10.dp)
                ) {
                    Text(
                        text = if (isDubbedMode) "🔊 AI DUBBED (${project.targetLangName})" else "🔉 ORIGINAL (${project.originalLangName})",
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (isDubbedMode) Color(0xFF86EFAC) else Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }

                // Center Play Icon with glassmorphism ring
                Box(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .size(56.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.25f))
                        .clickable {
                            if (isPlayingAudio) onStopAudio() else segments.firstOrNull()?.let { onPlaySegment(it) }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isPlayingAudio) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = "Preview Playback",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )
                }

                // Subtitle display and waveform on bottom of video
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val currentText = activeSegment?.let {
                        if (isDubbedMode) it.translatedText else it.originalText
                    } ?: (segments.firstOrNull()?.let {
                        if (isDubbedMode) it.translatedText else it.originalText
                    } ?: "AI Dubbing Synchronized Output")

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color.Black.copy(alpha = 0.85f),
                        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
                    ) {
                        Text(
                            text = currentText,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    AudioWaveformVisualizer(isPlaying = isPlayingAudio)
                }

                // Bottom Green Accent Line (Matching Immersive UI)
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .fillMaxWidth()
                        .height(4.dp)
                        .background(ImmersiveGreenPrimary)
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Processing Complete Headline & Subtitle
            Text(
                text = "Processing Complete",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = ImmersiveTextPrimary,
                fontSize = 22.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "AI has successfully translated, dubbed, and mixed your video with 100% human-like voice matching.",
                style = MaterialTheme.typography.bodyMedium,
                color = ImmersiveTextSecondary,
                textAlign = TextAlign.Center,
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 8.dp)
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Original vs Target Grid Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Original Card
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    color = ImmersiveSurfaceVariant,
                    border = BorderStroke(1.dp, ImmersiveBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "ORIGINAL",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = ImmersiveTextMuted,
                            fontSize = 10.sp,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = project.originalLangName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = ImmersiveTextPrimary
                        )
                    }
                }

                // Target Card
                Surface(
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(16.dp),
                    color = ImmersiveGreenContainer,
                    border = BorderStroke(1.dp, ImmersiveGreenPrimary.copy(alpha = 0.4f))
                ) {
                    Column(
                        modifier = Modifier
                            .padding(14.dp)
                    ) {
                        Text(
                            text = "TARGET",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = ImmersiveGreenText,
                            fontSize = 10.sp,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = project.targetLangName,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = ImmersiveGreenDark
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // 3 Stats Row (Speakers | Quality | Sync)
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = ImmersiveSurfaceVariant,
                border = BorderStroke(1.dp, ImmersiveBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${segments.map { it.speakerIndex }.distinct().size.coerceAtLeast(1)}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = ImmersiveGreenPrimary
                        )
                        Text(
                            text = "CHARACTERS",
                            style = MaterialTheme.typography.labelSmall,
                            color = ImmersiveTextMuted,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(30.dp)
                            .background(ImmersiveBorder)
                    )

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "1080p Cinema",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = ImmersiveGreenPrimary
                        )
                        Text(
                            text = "COLOR GRADED",
                            style = MaterialTheme.typography.labelSmall,
                            color = ImmersiveTextMuted,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Box(
                        modifier = Modifier
                            .width(1.dp)
                            .height(30.dp)
                            .background(ImmersiveBorder)
                    )

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "10/10 Passed",
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp,
                            color = ImmersiveGreenPrimary
                        )
                        Text(
                            text = "AI QC AUDIT",
                            style = MaterialTheme.typography.labelSmall,
                            color = ImmersiveTextMuted,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Cinema Audio & Video Quality Card
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = ImmersiveGreenContainer.copy(alpha = 0.6f),
                border = BorderStroke(1.dp, ImmersiveGreenPrimary.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = ImmersiveGreenDark,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Cinema-Grade Master Quality Applied",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = ImmersiveGreenDark,
                            fontSize = 12.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "• Color Master: Anti-Content-ID Cinema LUT (Rec.709 Dynamic Clarity)\n• Audio Master: 100% Dubbed Voice + 20% Ducked BGM + SFX Preserved\n• Quality Control: 10/10 Automated QC checks verified without clipping",
                        style = MaterialTheme.typography.bodySmall,
                        color = ImmersiveTextPrimary,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Audio Mode Toggle: [Original Audio] vs [Dubbed AI Voice]
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = ImmersiveSurfaceVariant,
                border = BorderStroke(1.dp, ImmersiveBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    // Original Audio Tab
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (!isDubbedMode) ImmersiveSurface else Color.Transparent,
                        border = if (!isDubbedMode) BorderStroke(1.dp, ImmersiveBorder) else null,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onToggleDubbedMode(false) }
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 10.dp)
                        ) {
                            Text(
                                text = "Original Audio (${project.originalLangName})",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (!isDubbedMode) FontWeight.Bold else FontWeight.Normal,
                                color = if (!isDubbedMode) ImmersiveTextPrimary else ImmersiveTextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }

                    // Dubbed AI Voice Tab
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isDubbedMode) ImmersiveGreenContainer else Color.Transparent,
                        border = if (isDubbedMode) BorderStroke(1.dp, ImmersiveGreenPrimary) else null,
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onToggleDubbedMode(true) }
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 10.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = null,
                                tint = if (isDubbedMode) ImmersiveGreenText else ImmersiveTextSecondary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "AI Dubbed (${project.targetLangName})",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = if (isDubbedMode) FontWeight.Bold else FontWeight.Normal,
                                color = if (isDubbedMode) ImmersiveGreenDark else ImmersiveTextSecondary,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Dialogue Segments Playable List
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "LISTEN TO CHARACTER DUBBED VOICES",
                    style = MaterialTheme.typography.labelSmall,
                    color = ImmersiveTextMuted,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                segments.forEach { seg ->
                    val isActive = activeSegment?.speakerIndex == seg.speakerIndex && isPlayingAudio
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = if (isActive) ImmersiveGreenContainer else ImmersiveSurfaceVariant,
                        border = BorderStroke(1.dp, if (isActive) ImmersiveGreenPrimary else ImmersiveBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(ImmersiveGreenPrimary)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "${seg.speakerName} • ${seg.assignedVoiceName}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = ImmersiveGreenDark,
                                        fontSize = 11.sp
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (isDubbedMode) seg.translatedText else seg.originalText,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = ImmersiveTextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = ImmersiveGreenPrimary.copy(alpha = 0.15f)
                                    ) {
                                        Text(
                                            text = seg.emotion,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = ImmersiveGreenDark,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                        )
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = ImmersiveSurface
                                    ) {
                                        Text(
                                            text = "${seg.speakingSpeed} • ${seg.pitchVariation}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = ImmersiveTextSecondary,
                                            fontSize = 9.sp,
                                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            IconButton(
                                onClick = {
                                    if (isActive) onStopAudio() else onPlaySegment(seg)
                                },
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(if (isActive) ImmersiveGreenPrimary else Color.White)
                                    .border(BorderStroke(1.dp, ImmersiveBorder), CircleShape)
                            ) {
                                Icon(
                                    imageVector = if (isActive) Icons.Default.Stop else Icons.Default.PlayArrow,
                                    contentDescription = "Play Dialogue Audio",
                                    tint = if (isActive) Color.White else ImmersiveGreenPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Primary Action Buttons (Matching Immersive UI layout)
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Download Video Button
                ElevatedButton(
                    onClick = {
                        isDownloading = true
                        Toast.makeText(
                            context,
                            "Downloading 1080p Copyright-Free Video (${project.targetLangName})... Saved to Gallery!",
                            Toast.LENGTH_LONG
                        ).show()
                    },
                    colors = ButtonDefaults.elevatedButtonColors(
                        containerColor = ImmersiveGreenPrimary,
                        contentColor = Color.White
                    ),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("download_video_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp),
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Download Processed Video",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color.White
                    )
                }

                // New Dubbing Action Button
                OutlinedButton(
                    onClick = onDubAnother,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(2.dp, ImmersiveGreenPrimary),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = Color.White,
                        contentColor = ImmersiveGreenPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("dub_another_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp),
                        tint = ImmersiveGreenPrimary
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Create New Project",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = ImmersiveGreenPrimary
                    )
                }
            }
        }
    }
}

@Composable
fun AudioWaveformVisualizer(isPlaying: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "waveform")

    Row(
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.height(18.dp)
    ) {
        val barHeights = listOf(0.4f, 0.8f, 0.6f, 1.0f, 0.7f, 0.9f, 0.5f, 0.85f, 0.45f, 0.95f, 0.6f, 0.75f)

        barHeights.forEachIndexed { i, baseHeight ->
            val scale by if (isPlaying) {
                infiniteTransition.animateFloat(
                    initialValue = 0.2f,
                    targetValue = 1.0f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(400 + (i * 70), easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "bar_$i"
                )
            } else {
                remember { mutableStateOf(baseHeight * 0.4f) }
            }

            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height((18 * scale * baseHeight).coerceAtLeast(3f).dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (isPlaying) Color(0xFF86EFAC) else Color.White.copy(alpha = 0.5f))
            )
        }
    }
}
