package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SampleVideoPreset
import com.example.data.model.SpeakerSegment
import com.example.ui.theme.ImmersiveBorder
import com.example.ui.theme.ImmersiveGreenContainer
import com.example.ui.theme.ImmersiveGreenDark
import com.example.ui.theme.ImmersiveGreenPrimary
import com.example.ui.theme.ImmersiveGreenText
import com.example.ui.theme.ImmersiveSurface
import com.example.ui.theme.ImmersiveSurfaceVariant
import com.example.ui.theme.ImmersiveTextMuted
import com.example.ui.theme.ImmersiveTextPrimary
import com.example.ui.theme.ImmersiveTextSecondary

@Composable
fun AiAnalysisCard(
    preset: SampleVideoPreset?,
    customTitle: String,
    modifier: Modifier = Modifier
) {
    val origLang = preset?.detectedOriginalLangName ?: "English (US)"
    val speakerCount = preset?.speakerCount ?: 2
    val bgm = preset?.bgmType ?: "Cinematic Ambient Electronic (Level: 20%)"
    val sfx = preset?.soundFxType ?: "Studio Room Acoustics & Environmental FX"
    val segments = preset?.segments ?: emptyList()

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("ai_analysis_card"),
        colors = CardDefaults.cardColors(containerColor = ImmersiveSurface),
        shape = RoundedCornerShape(24.dp),
        border = BorderStroke(1.dp, ImmersiveBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
        ) {
            // Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(ImmersiveGreenContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = ImmersiveGreenPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Automatic AI Analysis",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = ImmersiveTextPrimary
                    )
                }

                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = ImmersiveGreenContainer,
                    border = BorderStroke(1.dp, ImmersiveGreenPrimary.copy(alpha = 0.3f))
                ) {
                    Text(
                        text = "Auto-Analyzed",
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = ImmersiveGreenText,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Analysis Summary Grid (Matching the Immersive UI original vs target cards)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Language Detected
                AnalysisMiniBadge(
                    icon = Icons.Default.Language,
                    title = "ORIGINAL LANGUAGE",
                    value = origLang,
                    badgeColor = ImmersiveGreenPrimary,
                    modifier = Modifier.weight(1f)
                )

                // Speakers Detected
                AnalysisMiniBadge(
                    icon = Icons.Default.Person,
                    title = "SPEAKERS DETECTED",
                    value = "$speakerCount Characters",
                    badgeColor = ImmersiveGreenPrimary,
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // BGM & SFX Detection
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = ImmersiveSurfaceVariant,
                border = BorderStroke(1.dp, ImmersiveBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = ImmersiveGreenPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "BGM: $bgm",
                            style = MaterialTheme.typography.bodySmall,
                            color = ImmersiveTextSecondary,
                            fontSize = 12.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.GraphicEq,
                            contentDescription = null,
                            tint = ImmersiveGreenPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "SFX: $sfx",
                            style = MaterialTheme.typography.bodySmall,
                            color = ImmersiveTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            if (segments.isNotEmpty()) {
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "DETECTED SPEAKER DIALOGUES & TIMINGS",
                    style = MaterialTheme.typography.labelSmall,
                    color = ImmersiveTextMuted,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(10.dp))

                segments.take(3).forEachIndexed { idx, seg ->
                    SpeakerSegmentRow(segment = seg)
                    if (idx < segments.take(3).size - 1) {
                        Spacer(modifier = Modifier.height(8.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun AnalysisMiniBadge(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    value: String,
    badgeColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = ImmersiveSurfaceVariant,
        border = BorderStroke(1.dp, ImmersiveBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = null, tint = badgeColor, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = title, style = MaterialTheme.typography.labelSmall, color = ImmersiveTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = ImmersiveTextPrimary)
        }
    }
}

@Composable
fun SpeakerSegmentRow(segment: SpeakerSegment) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = ImmersiveSurfaceVariant,
        border = BorderStroke(1.dp, ImmersiveBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(if (segment.gender == "Female") ImmersiveGreenPrimary else ImmersiveGreenDark)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${segment.speakerName} (${segment.gender} • ${segment.emotion})",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = ImmersiveGreenDark
                    )
                }

                Text(
                    text = "${String.format("%.0f", segment.startTimeSec)}s - ${String.format("%.0f", segment.endTimeSec)}s",
                    style = MaterialTheme.typography.labelSmall,
                    color = ImmersiveTextMuted,
                    fontSize = 10.sp
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "\"${segment.originalText}\"",
                style = MaterialTheme.typography.bodySmall,
                color = ImmersiveTextSecondary,
                fontSize = 11.sp,
                maxLines = 2
            )
        }
    }
}
