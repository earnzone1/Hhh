package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainStudioScreen
import com.example.ui.theme.DubStudioTheme
import com.example.ui.viewmodel.DubStudioViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            DubStudioTheme {
                val studioViewModel: DubStudioViewModel = viewModel()
                MainStudioScreen(viewModel = studioViewModel)
            }
        }
    }
}

